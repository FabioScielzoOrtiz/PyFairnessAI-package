A Python package for fairness in AI.

We are currently working on the package.